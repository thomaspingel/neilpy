from distutils.core import setup

setup(
    name='NeilPy',
    version='0.1dev',
    packages=['neilpy',],
    license='MIT',
    long_description=open('README.txt').read(),
)